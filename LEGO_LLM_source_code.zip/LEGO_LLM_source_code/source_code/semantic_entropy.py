from __future__ import annotations

import math
import re
from collections import defaultdict
from typing import Callable, Iterable, Mapping, Sequence

import numpy as np


def _normalize_text(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text


def _shannon_entropy(probabilities: Sequence[float]) -> float:
    probs = np.asarray(probabilities, dtype=float)
    probs = probs[probs > 0]
    if probs.size == 0:
        return 0.0
    return float(-np.sum(probs * np.log(probs)))


def cluster_answers(
    answers: Sequence[str],
    entailment_fn: Callable[[str, str], bool] | None = None,
) -> list[list[str]]:
    """Cluster sampled answers into semantic groups.

    When an entailment function is unavailable, normalized exact-match clustering is used as
    a deterministic fallback. This keeps the implementation usable without an external NLI model.
    """

    if not answers:
        return []

    clusters: list[list[str]] = []
    normalized_answers = [_normalize_text(answer) for answer in answers]

    for raw_answer, normalized in zip(answers, normalized_answers):
        assigned = False
        for cluster in clusters:
            representative = cluster[0]
            rep_norm = _normalize_text(representative)
            if entailment_fn is not None:
                if entailment_fn(normalized, rep_norm) and entailment_fn(rep_norm, normalized):
                    cluster.append(raw_answer)
                    assigned = True
                    break
            elif normalized == rep_norm:
                cluster.append(raw_answer)
                assigned = True
                break

        if not assigned:
            clusters.append([raw_answer])

    return clusters


def semantic_entropy_from_samples(
    sampled_answers_by_question: Sequence[Sequence[str]],
    entailment_fn: Callable[[str, str], bool] | None = None,
) -> float:
    """Compute the paper-style semantic entropy for one language.

    Each question is associated with multiple sampled answers. Answers are clustered by semantic
    equivalence and converted to cluster probabilities before entropy is computed and summed over
    the questions of that language.
    """

    total_entropy = 0.0
    for answers in sampled_answers_by_question:
        clusters = cluster_answers(list(answers), entailment_fn=entailment_fn)
        if not clusters:
            continue
        cluster_sizes = np.array([len(cluster) for cluster in clusters], dtype=float)
        probabilities = cluster_sizes / cluster_sizes.sum()
        total_entropy += _shannon_entropy(probabilities)
    return float(total_entropy)


def fairness_variance_from_language_samples(
    language_to_sampled_answers: Mapping[str, Sequence[Sequence[str]]],
    entailment_fn: Callable[[str, str], bool] | None = None,
) -> float:
    entropies = []
    for sampled_answers in language_to_sampled_answers.values():
        entropies.append(semantic_entropy_from_samples(sampled_answers, entailment_fn=entailment_fn))

    if not entropies:
        return 0.0
    return float(np.var(np.asarray(entropies, dtype=float)))


def _infer_language_from_subtask(subtask_name: str) -> str:
    tokens = re.split(r"[_:/-]", subtask_name)
    if not tokens:
        return subtask_name
    return tokens[-1]


def fairness_proxy_from_lm_eval_results(results: Mapping, task: str, metric: str) -> float:
    """Score-based fallback used when sampled generations are unavailable.

    This is not identical to semantic entropy from sampled generations, but it preserves the
    *cross-language variance* part of the paper's fairness definition by computing an entropy-like
    value inside each language bucket and then taking the variance across buckets.
    """

    subtasks = results.get("group_subtasks", {}).get(task, [])
    grouped_scores: dict[str, list[float]] = defaultdict(list)

    for subtask in subtasks:
        score = results.get("results", {}).get(subtask, {}).get(metric)
        if score is None:
            continue
        language = _infer_language_from_subtask(subtask)
        grouped_scores[language].append(max(float(score), 0.0))

    if not grouped_scores:
        return 0.0

    entropies = []
    for scores in grouped_scores.values():
        probs = np.asarray(scores, dtype=float)
        if probs.sum() <= 0:
            entropies.append(0.0)
            continue
        probs = probs / probs.sum()
        entropies.append(_shannon_entropy(probs))

    return float(np.var(np.asarray(entropies, dtype=float)))


def compute_entropy(results, task, metric, language_to_sampled_answers=None, entailment_fn=None):
    if language_to_sampled_answers is not None:
        return fairness_variance_from_language_samples(
            language_to_sampled_answers,
            entailment_fn=entailment_fn,
        )
    return fairness_proxy_from_lm_eval_results(results, task, metric)
