from __future__ import annotations

import random
from typing import Dict, Sequence

import numpy as np
import torch.nn as nn
from pymoo.core.population import Population
from pymoo.core.problem import ElementwiseProblem

from moea_llm_merge.assembly import (
    Chromosome,
    LayerAssemblyOperator,
    LayerGene,
    ParticipantSpec,
    extract_decoder_layers,
)
from .eval_utils import evaluate_chromosome
from .logging_utils import log_event, maybe_log


def ensure_2d_array(x):
    arr = np.asarray(x)
    if arr.ndim == 0:
        return arr.reshape(1, 1)
    if arr.ndim == 1:
        return arr.reshape(1, -1)
    return arr



def get_beta_from_index(index: int, num_candidates: int) -> float:
    if num_candidates <= 1:
        return 0.5
    values = np.linspace(0.0, 1.0, num_candidates)
    return float(values[int(np.clip(index, 0, num_candidates - 1))])



def initialize_unified_population(
    source_models: Sequence[nn.Module],
    args,
) -> list[list[int]]:
    population: list[list[int]] = []

    substitute_id = list(LayerAssemblyOperator).index(LayerAssemblyOperator.SUBSTITUTE)
    merge_id = list(LayerAssemblyOperator).index(LayerAssemblyOperator.MERGE)

    for model_idx, model in enumerate(source_models):
        layers = extract_decoder_layers(model)
        chromosome: list[int] = []
        vertical_specs = []

        for depth in range(args.new_model_layers):
            src_layer = min(depth, len(layers) - 1)
            chromosome.extend([model_idx, src_layer])
            vertical_specs.append((model_idx, src_layer))

        for _ in range(args.new_model_layers):
            chromosome.extend([0, 0, 0, substitute_id])

        chromosome.append(args.beta_candidates // 2)
        population.append(chromosome)

        chromosome2: list[int] = []
        for model_idx2, layer_idx2 in vertical_specs:
            chromosome2.extend([model_idx2, layer_idx2])

        for model_idx2, layer_idx2 in vertical_specs:
            chromosome2.extend([1, model_idx2, layer_idx2, merge_id])

        chromosome2.append(args.beta_candidates // 2)
        population.append(chromosome2)

    while len(population) < args.population_size:
        chromosome = []

        for _ in range(args.new_model_layers):
            model_idx = random.randint(0, len(source_models) - 1)
            max_layer_idx = len(extract_decoder_layers(source_models[model_idx])) - 1
            chromosome.extend([model_idx, random.randint(0, max_layer_idx)])

        for _ in range(args.new_model_layers):
            use_secondary = random.randint(0, 1)
            model_idx = random.randint(0, len(source_models) - 1)
            max_layer_idx = len(extract_decoder_layers(source_models[model_idx])) - 1
            layer_idx = random.randint(0, max_layer_idx)
            operator_id = random.choice(LayerAssemblyOperator.ids())
            chromosome.extend([use_secondary, model_idx, layer_idx, operator_id])

        chromosome.append(random.randint(0, max(0, args.beta_candidates - 1)))
        population.append(chromosome)

    return population[: args.population_size]



def population_from_list(individuals: Sequence[Sequence[int]]) -> Population:
    return Population.new("X", np.asarray(individuals, dtype=int))



def decode_vertical(
    x: Sequence[int],
    source_models: Sequence[nn.Module],
    num_layers: int,
) -> tuple[ParticipantSpec, ...]:
    specs = []
    for offset in range(0, num_layers * 2, 2):
        model_idx = int(x[offset]) % len(source_models)
        max_layer_idx = len(extract_decoder_layers(source_models[model_idx])) - 1
        layer_idx = int(np.clip(x[offset + 1], 0, max_layer_idx))
        specs.append(ParticipantSpec(model_idx=model_idx, layer_idx=layer_idx, active=True))
    return tuple(specs)



def decode_horizontal(
    x: Sequence[int],
    source_models: Sequence[nn.Module],
    vertical_specs: Sequence[ParticipantSpec],
    beta_candidates: int,
) -> tuple[tuple[LayerGene, ...], float]:
    genes = []
    cursor = 0

    for primary in vertical_specs:
        use_secondary = bool(int(x[cursor]))
        model_idx = int(x[cursor + 1]) % len(source_models)
        max_layer_idx = len(extract_decoder_layers(source_models[model_idx])) - 1
        layer_idx = int(np.clip(x[cursor + 2], 0, max_layer_idx))
        operator = LayerAssemblyOperator.from_id(int(x[cursor + 3]))

        secondary = (
            ParticipantSpec(model_idx=model_idx, layer_idx=layer_idx, active=True)
            if use_secondary
            else None
        )

        if secondary is None:
            operator = LayerAssemblyOperator.SUBSTITUTE

        genes.append(LayerGene(primary=primary, secondary=secondary, operator=operator))
        cursor += 4

    beta_idx = int(x[cursor]) if cursor < len(x) else beta_candidates // 2
    beta = get_beta_from_index(beta_idx, beta_candidates)
    return tuple(genes), beta



def decode_unified_chromosome(
    x: Sequence[int],
    source_models: Sequence[nn.Module],
    args,
) -> Chromosome:
    x = list(map(int, x))

    vertical_len = args.new_model_layers * 2
    horizontal_len = args.new_model_layers * 4

    vertical_part = x[:vertical_len]
    horizontal_part = x[vertical_len: vertical_len + horizontal_len]
    beta_part = x[vertical_len + horizontal_len:]

    vertical_specs = decode_vertical(
        vertical_part,
        source_models,
        args.new_model_layers,
    )
    horizontal_genes, beta = decode_horizontal(
        horizontal_part + beta_part,
        source_models,
        vertical_specs,
        args.beta_candidates,
    )

    return Chromosome(
        vertical=vertical_specs,
        horizontal=horizontal_genes,
        beta=beta,
    )



class UnifiedChromosomeProblem(ElementwiseProblem):
    """
    Single-layer bi-objective search over the full chromosome:
      objective 1: maximize score   -> minimize -score
      objective 2: minimize fairness
    """

    def __init__(
        self,
        source_models: Sequence[nn.Module],
        tokenizer,
        args,
    ):
        self.source_models = source_models
        self.tokenizer = tokenizer
        self.args = args
        self.eval_cache: Dict[Chromosome, tuple[float, float]] = {}

        n_var = args.new_model_layers * 2 + args.new_model_layers * 4 + 1

        xl, xu = [], []
        max_layers_global = max(len(extract_decoder_layers(m)) for m in source_models) - 1

        for _ in range(args.new_model_layers):
            xl.extend([0, 0])
            xu.extend([len(source_models) - 1, max_layers_global])

        for _ in range(args.new_model_layers):
            xl.extend([0, 0, 0, 0])
            xu.extend([
                1,
                len(source_models) - 1,
                max_layers_global,
                len(LayerAssemblyOperator) - 1,
            ])

        xl.append(0)
        xu.append(max(0, args.beta_candidates - 1))

        super().__init__(
            n_var=n_var,
            n_obj=2,
            xl=np.asarray(xl),
            xu=np.asarray(xu),
            type_var=np.int_,
        )

    def _evaluate(self, x, out, *args, **kwargs):
        algorithm = kwargs.get("algorithm", None)
        gen = getattr(algorithm, "n_gen", "")

        chromosome = decode_unified_chromosome(
            x,
            self.source_models,
            self.args,
        )

        maybe_log(
            self.args,
            f"[Unified] evaluating candidate | gen={gen} | layers={len(chromosome.vertical)} | beta={chromosome.beta:.4f}",
        )

        log_event(
            self.args,
            stage="unified",
            event="candidate_start",
            generation=gen,
            beta=f"{chromosome.beta:.6f}",
            num_layers=len(chromosome.vertical),
        )

        score, fairness = evaluate_chromosome(
            chromosome,
            self.source_models,
            self.tokenizer,
            self.args,
            self.eval_cache,
        )

        maybe_log(
            self.args,
            f"[Unified] candidate finished | gen={gen} | score={score:.6f} | fairness={fairness:.6f}",
        )

        log_event(
            self.args,
            stage="unified",
            event="candidate_end",
            generation=gen,
            score=f"{score:.6f}",
            fairness=f"{fairness:.6f}",
            beta=f"{chromosome.beta:.6f}",
            num_layers=len(chromosome.vertical),
        )

        out["F"] = np.asarray([-score, fairness], dtype=float)
