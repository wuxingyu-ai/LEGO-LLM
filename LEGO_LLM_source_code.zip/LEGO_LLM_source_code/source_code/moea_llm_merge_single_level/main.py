from __future__ import annotations


import os
import sys

if __name__ == "__main__" and (__package__ is None or __package__ == ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    __package__ = "moea_llm_merge_single_level"

from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.termination import get_termination

from moea_llm_merge.assembly import load_source_models
from .config import args_parse, set_seed
from .eval_utils import save_final_outputs
from .logging_utils import log_event, maybe_log, setup_csv_logger
from .search import (
    UnifiedChromosomeProblem,
    decode_unified_chromosome,
    ensure_2d_array,
    initialize_unified_population,
    population_from_list,
)

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "1,2")


def main():
    args = args_parse()
    set_seed(args.seed)
    setup_csv_logger(args)

    try:
        maybe_log(
            args,
            f"[Main] single-layer NSGA-II | pop={args.population_size}, gen={args.generations}",
        )
        maybe_log(args, f"[Main] CSV log path: {args.csv_log_path}")

        log_event(
            args,
            stage="main",
            event="start",
            note=f"single-layer bi-objective NSGA-II | pop={args.population_size}, gen={args.generations}",
        )

        source_models, tokenizer = load_source_models(args.model_paths, args.dtype)

        problem = UnifiedChromosomeProblem(
            source_models=source_models,
            tokenizer=tokenizer,
            args=args,
        )

        initial_population = population_from_list(
            initialize_unified_population(source_models, args)
        )

        algorithm = NSGA2(
            pop_size=args.population_size,
            eliminate_duplicates=True,
        )

        result = minimize(
            problem,
            algorithm,
            get_termination("n_gen", args.generations),
            x0=initial_population,
            verbose=not args.quiet,
            seed=args.seed,
        )

        result_F = ensure_2d_array(result.F)
        result_X = ensure_2d_array(result.X)

        best_idx = int(np.argmin(result_F[:, 0]))
        best_x = result_X[best_idx]
        best_chromosome = decode_unified_chromosome(best_x, source_models, args)

        save_final_outputs(best_chromosome, source_models, tokenizer, args)

        log_event(
            args,
            stage="main",
            event="end",
            beta=f"{best_chromosome.beta:.6f}",
            num_layers=len(best_chromosome.vertical),
            note=f"best model saved to {args.save_path}",
        )

        maybe_log(args, f"Best chromosome saved to: {args.save_path}")
    finally:
        logger = getattr(args, "csv_logger", None)
        if logger is not None:
            logger.close()
