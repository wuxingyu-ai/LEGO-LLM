from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import torch.nn as nn
import os
import lm_eval
import lm_eval.api.model
import lm_eval.models.huggingface
import lm_eval.tasks
import json
import numpy as np

os.environ["CUDA_VISIBLE_DEVICES"] = "2,3,4"

def convert_int64(obj):
    if isinstance(obj, dict):
        return {k: convert_int64(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_int64(v) for v in obj]
    elif isinstance(obj, np.int64):
        return int(obj)
    else:
        return obj

def default_converter(obj):
    if isinstance(obj, np.int64):
        return int(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")

def save_results_to_json(results, filename):
    results = convert_int64(results)   
    with open(filename, "w") as json_file:
        json.dump(results, json_file, indent=4, default=default_converter)


def main():
    print(torch.cuda.device_count())
    Model = "your model"
    
    model_path = "model_path"
    model_hf = lm_eval.models.huggingface.HFLM(model_path, device = "cuda", parallelize = True)

    task = "xnli"
    limit_pre = 0.2
    metric = "acc,none"

    results = lm_eval.evaluator.simple_evaluate(model=model_hf, tasks=[task], limit =limit_pre, batch_size = 4, verbosity="WARNING")
    extracted_data = {
    "results": results["results"],
    "groups": results["groups"],
    "group_subtasks": results["group_subtasks"]
    }
    score = results["results"][task][metric]
    print("score", score)
    save_results_to_json(extracted_data, f"./{Model}_{task}_{limit_pre}.json")
if __name__ == "__main__":
    main()